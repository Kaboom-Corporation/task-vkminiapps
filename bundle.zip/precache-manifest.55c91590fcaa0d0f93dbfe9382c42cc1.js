self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8f702546b4132123efe4fd79b7f54a4f",
    "url": "/index.html"
  },
  {
    "revision": "140d17b34c0bb8a80a85",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "140d17b34c0bb8a80a85",
    "url": "/static/js/2.a91b5c2c.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.a91b5c2c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ede2256cb254d1f4c51d",
    "url": "/static/js/main.ddabb4f6.chunk.js"
  },
  {
    "revision": "2f729f8dfb644b1198eb",
    "url": "/static/js/runtime-main.4146942f.js"
  }
]);